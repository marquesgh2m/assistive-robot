#include <unistd.h>
#include <string.h>
#include <libplayercore/playercore.h>


#ifndef _ARDUBOTDEVICE_H
#define _ARDUBOTDEVICE_H

class Ardubot : public Driver
{
public:
Ardubot(ConfigFile* cf, int section);

 virtual int Setup();
 virtual int Shutdown();

 virtual int ProcessMessage(MessageQueue* resp_queue,player_msghdr *hdr,void * data);

 private:
 virtual void Main();
 int intTest;
 };

#endif

