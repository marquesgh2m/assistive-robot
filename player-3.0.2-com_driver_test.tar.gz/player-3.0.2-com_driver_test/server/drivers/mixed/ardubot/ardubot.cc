#include "ardubot.h"

 Driver* Ardubot_Init(ConfigFile* cf, int section)
 {
 return((Driver*)(new Ardubot(cf, section)));
 }

 void Ardubot_Register(DriverTable* table)
 {
 table->AddDriver("ardubot", Ardubot_Init);
 }


extern "C" {
 int player_driver_init(DriverTable* table)
 {
   puts("ardubot initializing");
   Ardubot_Register(table);
   puts("ardubot done");
   return(0);
 }
}

 Ardubot::Ardubot(ConfigFile* cf, int section) : Driver(cf,section, false, 
 PLAYER_MSGQUEUE_DEFAULT_MAXLEN, PLAYER_POSITION2D_CODE)
 {
 //this->in_section = cf->ReadInt(section, "player_interface", 0);
 return;
 }

 int Ardubot::Setup()
 {
 //StartThread();
 return(0);
 }

 int Ardubot::Shutdown()
 {
 //StopThread();
 return(0);
 }

 int Ardubot::ProcessMessage(MessageQueue* resp_queue, player_msghdr* hdr, void * data)
 {
 return(0);
 }

 void Ardubot::Main()
 {
	 for(;;)	 {
		 //pthread_testcancel();
		 ProcessMessages();
		 usleep(100000);
	 }
 }


